#! /usr/bin/env node
import { program } from 'commander';
import run from './commands/run.js';

program
    .command('run')
    .option('-p, --path <path>', 'Path to files (default: current directory)')
    .option('-f, --filter <filter>', 'Filter which files should be runned (default: "*")')
    .option('-e, --errors', 'Show detailed error messages')
    .description('Runs all .js files in selected path')
    .action(run);

program.parse();